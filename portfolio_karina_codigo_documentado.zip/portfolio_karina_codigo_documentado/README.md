# Portfólio — Karina Inácio Corrêa

Este projeto foi organizado para ser fácil de ler, explicar, editar e publicar.

## Estrutura

```text
portfolio_karina_codigo_documentado/
├── index.html
├── css/
│   └── estilos.css
├── js/
│   ├── navegacao.js
│   └── animacoes.js
└── assets/
    └── imagens/
        └── foto-karina.jpg
```

## O que fica em cada arquivo

- **index.html**: conteúdo do portfólio e estrutura das seções.
- **css/estilos.css**: aparência, cores, tamanhos, cards, animações e responsividade.
- **js/navegacao.js**: somente abertura e fechamento do menu mobile.
- **js/animacoes.js**: animações de entrada, barra de progresso e cursor interativo.
- **assets/imagens/foto-karina.jpg**: foto usada na apresentação.

## Como localizar cada seção

No `index.html`, procure pelos comentários:

- `SEÇÃO 01 — INÍCIO / APRESENTAÇÃO PROFISSIONAL`
- `SEÇÃO 02 — SOBRE MIM`
- `SEÇÃO 03 — EXPERIÊNCIA PROFISSIONAL`
- `SEÇÃO 04 — HABILIDADES TÉCNICAS`
- `SEÇÃO 05 — CERTIFICADOS`
- `SEÇÃO 06 — OBJETIVO PROFISSIONAL`
- `SEÇÃO 07 — CONTATO`

## Como testar

Abra `index.html` no navegador.

Para publicar no GitHub Pages, mantenha `index.html` na raiz do repositório e envie também as pastas `css`, `js` e `assets`.

## Observação importante

A última experiência profissional está registrada com término em **01/10/2026**. O texto do site não apresenta esse vínculo como emprego atual.
